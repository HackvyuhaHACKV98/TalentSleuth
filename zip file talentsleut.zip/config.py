import os

# Base directory
basedir = os.path.abspath(os.path.dirname(__file__))

# Configuration settings
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    UPLOAD_FOLDER = os.path.join(basedir, 'uploads')
    ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload size
    DATABASE_URL = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'talent_sleuth.db')
    
    # API Keys (in a real app, these would be environment variables)
    LINKEDIN_API_KEY = ''
    GITHUB_API_KEY = ''