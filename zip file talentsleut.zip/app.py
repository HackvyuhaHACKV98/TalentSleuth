import os
from flask import Flask, render_template, request, jsonify, redirect, url_for
from werkzeug.utils import secure_filename
import pdfplumber
import docx2txt
import re
import sqlite3
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import threading
import time

app = Flask(__name__)

# Set upload folder and max size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize NLTK
nltk.download('punkt')
nltk.download('stopwords')

# Database setup
def init_db():
    conn = sqlite3.connect('talent_sleuth.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS candidates
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT,
                  email TEXT,
                  phone TEXT,
                  resume_path TEXT,
                  analysis_date TEXT,
                  score REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS analysis_results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  candidate_id INTEGER,
                  category TEXT,
                  content TEXT,
                  FOREIGN KEY(candidate_id) REFERENCES candidates(id))''')
    conn.commit()
    conn.close()

init_db()

# Resume parsing functions
def parse_pdf(filepath):
    text = ""
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            text += page.extract_text()
    return text

def parse_docx(filepath):
    return docx2txt.process(filepath)

def extract_info(text):
    # Extract name
    name = re.findall(r'([A-Z][a-z]+(?:\s[A-Z][a-z]+)+)', text)
    name = name[0] if name else "Unknown"
    # Extract email
    email = re.findall(r'[\w\.-]+@[\w\.-]+', text)
    email = email[0] if email else ""
    # Extract phone
    phone = re.findall(r'(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4})', text)
    phone = phone[0] if phone else ""
    # Extract skills (simplified)
    skills = re.findall(r'(?i)(python|java|c\+\+|javascript|flask|django|machine learning|ai|artificial intelligence|data science|sql|nosql|react|angular|vue)', text)
    skills = list(set(skills))  # Remove duplicates
    # Extract education
    education = []
    edu_keywords = ['university', 'college', 'institute', 'school', 'bachelor', 'master', 'phd', 'degree']
    sentences = re.split(r'\.|\n', text)
    for sentence in sentences:
        if any(word.lower() in sentence.lower() for word in edu_keywords):
            education.append(sentence.strip())
    # Extract experience
    experience = []
    exp_keywords = ['experience', 'worked', 'job', 'position', 'employed', 'intern']
    for sentence in sentences:
        if any(word.lower() in sentence.lower() for word in exp_keywords):
            experience.append(sentence.strip())
    return {
        'name': name,
        'email': email,
        'phone': phone,
        'skills': skills,
        'education': education,
        'experience': experience,
        'raw_text': text
    }

# AI Analysis functions
def calculate_fit_score(resume_text, job_description):
    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = vectorizer.fit_transform([resume_text, job_description])
    cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    return round(cosine_sim[0][0] * 100, 2)

def analyze_red_flags(data):
    red_flags = []
    # Check for short job durations
    experience_text = ' '.join(data['experience'])
    short_jobs = re.findall(r'(\d{1,2})\s*(month|months)', experience_text, re.IGNORECASE)
    if len(short_jobs) > 2:
        red_flags.append(f"Multiple short-term jobs ({len(short_jobs)} positions < 1 year)")
    # Check skill consistency
    if len(data['skills']) < 5:
        red_flags.append("Limited skills listed")
    # Check education
    if not data['education']:
        red_flags.append("No education information found")
    return red_flags

# Web scraping functions (simplified examples)
def search_linkedin(name):
    return {"status": "info", "message": "LinkedIn data requires API access"}

def search_github(name):
    try:
        url = f"https://api.github.com/users/{name}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        return {"status": "error", "message": "GitHub profile not found"}
    except:
        return {"status": "error", "message": "Error accessing GitHub"}

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_resume():
    if request.method == 'POST':
        if 'resume' not in request.files:
            return redirect(request.url)
        file = request.files['resume']
        if file.filename == '':
            return redirect(request.url)
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            # Parse resume
            if filename.endswith('.pdf'):
                text = parse_pdf(filepath)
            elif filename.endswith('.docx'):
                text = parse_docx(filepath)
            else:
                text = file.read().decode('utf-8')
            data = extract_info(text)
            # Save to database
            conn = sqlite3.connect('talent_sleuth.db')
            c = conn.cursor()
            c.execute("INSERT INTO candidates (name, email, phone, resume_path, analysis_date) VALUES (?, ?, ?, ?, ?)",
                      (data['name'], data['email'], data['phone'], filepath, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            candidate_id = c.lastrowid
            # Save analysis results
            for skill in data['skills']:
                c.execute("INSERT INTO analysis_results (candidate_id, category, content) VALUES (?, ?, ?)",
                          (candidate_id, 'skill', skill))
            for edu in data['education']:
                c.execute("INSERT INTO analysis_results (candidate_id, category, content) VALUES (?, ?, ?)",
                          (candidate_id, 'education', edu))
            for exp in data['experience']:
                c.execute("INSERT INTO analysis_results (candidate_id, category, content) VALUES (?, ?, ?)",
                          (candidate_id, 'experience', exp))
            conn.commit()
            conn.close()
            # Start background checks
            threading.Thread(target=background_checks, args=(candidate_id, data)).start()
            return redirect(url_for('analysis', candidate_id=candidate_id))
        return redirect(request.url)
    # GET request: render upload form
    return render_template('upload.html')

def background_checks(candidate_id, data):
    time.sleep(2)
    conn = sqlite3.connect('talent_sleuth.db')
    c = conn.cursor()
    # LinkedIn check
    linkedin_data = search_linkedin(data['name'])
    c.execute("INSERT INTO analysis_results (candidate_id, category, content) VALUES (?, ?, ?)",
              (candidate_id, 'linkedin', str(linkedin_data)))
    # GitHub check
    github_data = search_github(data['name'])
    c.execute("INSERT INTO analysis_results (candidate_id, category, content) VALUES (?, ?, ?)",
              (candidate_id, 'github', str(github_data)))
    conn.commit()
    conn.close()

@app.route('/analysis/<int:candidate_id>')
def analysis(candidate_id):
    conn = sqlite3.connect('talent_sleuth.db')
    c = conn.cursor()
    # Get candidate info
    c.execute("SELECT * FROM candidates WHERE id=?", (candidate_id,))
    candidate = c.fetchone()
    # Get analysis results
    c.execute("SELECT category, content FROM analysis_results WHERE candidate_id=?", (candidate_id,))
    results = c.fetchall()
    conn.close()
    # Organize results
    analysis_data = {
        'skills': [],
        'education': [],
        'experience': [],
        'linkedin': {},
        'github': {}
    }
    for category, content in results:
        if category in analysis_data:
            if category in ['linkedin', 'github']:
                try:
                    analysis_data[category] = eval(content)
                except:
                    analysis_data[category] = {'data': content}
            else:
                analysis_data[category].append(content)
    # Calculate score (simplified)
    job_description = request.args.get('jd', '')
    if job_description:
        c.execute("SELECT raw_text FROM candidates WHERE id=?", (candidate_id,))
        raw_text = c.fetchone()[0]
        score = calculate_fit_score(raw_text, job_description)
    else:
        score = None
    # Check red flags
    red_flags = analyze_red_flags(analysis_data)
    return render_template('analysis.html',
                           candidate=candidate,
                           analysis=analysis_data,
                           score=score,
                           red_flags=red_flags,
                           job_description=job_description)

@app.route('/dashboard')
def dashboard():
    conn = sqlite3.connect('talent_sleuth.db')
    c = conn.cursor()
    c.execute("SELECT * FROM candidates ORDER BY analysis_date DESC")
    candidates = c.fetchall()
    conn.close()
    return render_template('dashboard.html', candidates=candidates)

if __name__ == '__main__':
    app.run(debug=True)
